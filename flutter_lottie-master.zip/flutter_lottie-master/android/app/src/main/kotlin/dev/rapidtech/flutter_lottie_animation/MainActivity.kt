package dev.rapidtech.flutter_lottie_animation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
